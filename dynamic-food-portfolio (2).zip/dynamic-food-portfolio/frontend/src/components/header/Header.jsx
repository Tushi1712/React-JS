import React from 'react'
import './Header.css'

const Header = () => {
  return (
    <div className='header'>
        <div className="header-contents">
            <h2>Order your dish for faster delivery !!!</h2>
            <p>"Welcome to a world of irresistible flavors and culinary convenience! Our online food platform is designed to bring you an exceptional dining experience right to your doorstep. Whether you're craving classic comfort food or exploring adventurous international cuisines, we've got something for every palate. With a focus on quality, freshness, and speed, we partner with the best local restaurants and chefs to ensure your meals are nothing short of amazing. Browse, order, and savor—because great food is just a click away!"</p>
            <button>View Menu</button>
        </div>
    </div>
  )
}

export default Header