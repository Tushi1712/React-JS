import React, { useState } from 'react';
import {assets} from '../../assets/assets' // Adjust the import path for your assets
import './LoginPopUp.css'; // Adjust the import path for your CSS
import { useNavigate } from 'react-router-dom';

const LoginPopup = () => {
    const [showLogin, setShowLogin] = useState(true);
    const [currState, setCurrState] = useState("Login");

    const navigate = useNavigate();

    return (
        <div className='login-popup'>
            {showLogin && (
                <form className="login-popup-container">
                    <div className="login-popup-title">
                        <h2>{currState}</h2>
                        <img 
                            onClick={() => {
                                setShowLogin(false); // Hide the popup
                                navigate('/') // Attempt to close the page
                            }} 
                            src={assets.cross_icon} 
                            alt="Close Icon" 
                            style={{ cursor: 'pointer' }}

                        />
                    </div>
                    <div className="login-popup-inputs">
                        {currState === "Login" ? null : (
                            <input type="text" placeholder='Your Name' required />
                        )}
                        <input type="email" placeholder='Your Email' required />
                        <input type="password" placeholder='Password' required />
                    </div>
                    <button>{currState === "Sign Up" ? "Create Account" : "Login"}</button>
                    <div className="login-popup-condition">
                        <input type="checkbox" required/>
                        <p>I agree to the T&C applied for the privacy policy used</p>
                    </div>
                    {currState === "Login" ? (
                        <p>
                            Create a New Account? 
                            <span onClick={() => setCurrState("Sign Up")}>Click Here</span>
                        </p>
                    ) : (
                        <p>
                            Already have an Account? 
                            <span onClick={() => setCurrState("Login")}>Login Here</span>
                        </p>
                    )}
                </form>
            )}
        </div>
    );
};

export default LoginPopup;